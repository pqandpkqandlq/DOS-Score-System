#include<iostream>
#include<fstream>
#include"ScoreList.h"
using namespace std;
static ScoreList list;
void Start() {
	cout << VERSION << endl;
	cout << WELCOME << endl;
	cout << FIRST_USE << endl;
}
string getCommand() {
	string command;
	cout << COMMAND_PROMPT;
	cin >> command;
	return command;
}
int main() {
	//Student s("0", 1, 2, 3, 4, 5);
	//list.Stu_Add(s);
	//list.List_Print();
	//list.Stu_Add(s);
	//list.List_Print();
	//list.Stu_Add(s);
	//list.List_Print();
	//list.Stu_Add(s);
	//list.List_Print();
	string command;
	Start();
	while (1) {
		command = getCommand();
		if (command == ADD) {
			string number;
			double ch, math, eng, sci, soc;
			cout << "Input information" << endl;
			cout << "Input number,Chinese,maths,English,science,society:";
			cin >> number >> ch >> math >> eng >> sci >> soc;
			list.Stu_Add(Student(number, ch, math, eng, sci, soc));
			cout << COMMAND_SUCCESS << endl;
		}
		else if (command == DEL) {
			string number;
			cout << "Input the number who you want to delete:";
			cin >> number;
			list.Stu_Del(number);
			cout << COMMAND_SUCCESS << endl;
		}
		else if (command == CLEAN) {
			string code;
			cout << "Warning!Do you want to delete all student?!\n";
			cout << "Are you OK?\n";
			cout << "If you are OK,input this code:IWANTIT:";
			cin >> code;
			if (code == "IWANTIT") {
				list.List_Clean();
				cout << COMMAND_SUCCESS << endl;
			}
			else { cout << "Failed:Code is not true" << endl; }
		}
		else if (command == SORT_CH) {
			list.List_Sort_ch();
			cout << COMMAND_SUCCESS << endl;
		}
		else if (command == SORT_MATH) {
			list.List_Sort_math();
			cout << COMMAND_SUCCESS << endl;
		}
		else if (command == SORT_ENG) {
			list.List_Sort_eng();
			cout << COMMAND_SUCCESS << endl;
		}
		else if (command == SORT_SCI) {
			list.List_Sort_sci();
			cout << COMMAND_SUCCESS << endl;
		}
		else if (command == SORT_SOC) {
			list.List_Sort_soc();
			cout << COMMAND_SUCCESS << endl;
		}
		else if (command == SORT_AVER) {
			list.List_Sort_aver();
			cout << COMMAND_SUCCESS << endl;
		}
		else if (command == SORT_SUM) {
			list.List_Sort_sum();
			cout << COMMAND_SUCCESS << endl;
		}
		else if (command == PRINT) {
			list.List_Print();
		}
		else if (command == SAVE) {
			string filename;
			cout << "Input the file name:";
			cin >> filename;
			const char* name = filename.c_str();
			ofstream oFile(name, ios::out | ios::binary);
			oFile.write((char*)&list, sizeof(list));
			oFile.close();
			cout << "Done!File name:(ProgramRoot)\\" << filename << endl;
		}
		else if (command == LOAD) {
			string filename;
			cout << "Input the file name:";
			cin >> filename;
			const char* name = filename.c_str();
			ifstream iFile(name, ios::in | ios::binary);
			iFile.read((char*)&list, sizeof(list));
			iFile.close();
			cout << "Done!" << endl;
		}
		else if (command == SHUTDOWN) {
			return 0;
		}
		else if (command == HELP) {
			cout << "help\tIf you need help,input this\n";
			cout << "add\tAdd a student in this list\n";
			cout << "del\tDelete a student in this list\n";
			cout << "clean\tDelete all students in this list\n";
			cout << "sortch\tsort this list,standard is Chinese\n";
			cout << "sortmath\tsort this list,standard is Maths\n";
			cout << "sorteng\tsort this list,standard is English\n";
			cout << "sortsci\tsort this list,standard is Science\n";
			cout << "sortsoc\tsort this list,standard is Society\n";
			cout << "sortaver\tsort this list,standard is Average\n";
			cout << "sortsum\tsort this list,standard is all scores\n";
			cout << "print\tprint this list\n";
			cout << "save\tsave this list in your disk\n";
			cout << "load\tload a file in your disk and input this list\n";
			cout << "shutdown\tabandon this list and shutdown DOS Score System\n";
			cout << "Do not use capital letter!Use small letter!\n";
		}
		else if (command == SORT) {
			cout << "This is not complete command,did you mean:sort(subject)?" << endl;
		}
		else {
			cout << COMMAND_FAILED << endl;
		}
	}
	return 1;
}