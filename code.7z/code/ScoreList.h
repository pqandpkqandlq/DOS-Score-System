#pragma once
#include"Student.h"
#include<iostream>
class ScoreList {
	Student List[LIST_MAX];
	int Size;
public:
	ScoreList() :Size(0) {}
	void Stu_Add(Student stu) {
		if (Size >= LIST_MAX - 1) {
			cout << "Failed:The list is full" << endl;
			return;
		}
		List[Size] = stu;
		Size += 1;
	}
	void Stu_Del(string number) {
		for (int i = 0; i < Size; i++) {
			if (List[i].Number == number) {
				for (int j = i; j < Size; j++) {
					List[j] = List[j + 1];
				}
				Size -= 1;
			}
		}
	}
	void List_Clean() {
		Size = 0;
	}
	void List_Sort_ch() {
		for (int i = 0; i < Size - 1; i++) {
			for (int j = 0; j < Size - i - 1; j++) {
				if (List[j].Scores[0] < List[j + 1].Scores[0]) {
					Student temp = List[j];
					List[j] = List[j + 1];
					List[j + 1] = temp;
				}
			}
		}
	}
	void List_Sort_math() {
		for (int i = 0; i < Size - 1; i++) {
			for (int j = 0; j < Size - i - 1; j++) {
				if (List[j].Scores[1] < List[j + 1].Scores[1]) {
					Student temp = List[j];
					List[j] = List[j + 1];
					List[j + 1] = temp;
				}
			}
		}
	}
	void List_Sort_eng() {
		for (int i = 0; i < Size - 1; i++) {
			for (int j = 0; j < Size - i - 1; j++) {
				if (List[j].Scores[2] < List[j + 1].Scores[2]) {
					Student temp = List[j];
					List[j] = List[j + 1];
					List[j + 1] = temp;
				}
			}
		}
	}
	void List_Sort_sci() {
		for (int i = 0; i < Size - 1; i++) {
			for (int j = 0; j < Size - i - 1; j++) {
				if (List[j].Scores[3] < List[j + 1].Scores[3]) {
					Student temp = List[j];
					List[j] = List[j + 1];
					List[j + 1] = temp;
				}
			}
		}
	}
	void List_Sort_soc() {
		for (int i = 0; i < Size - 1; i++) {
			for (int j = 0; j < Size - i - 1; j++) {
				if (List[j].Scores[4] < List[j + 1].Scores[4]) {
					Student temp = List[j];
					List[j] = List[j + 1];
					List[j + 1] = temp;
				}
			}
		}
	}
	void List_Sort_aver() {
		for (int i = 0; i < Size - 1; i++) {
			for (int j = 0; j < Size - i - 1; j++) {
				if (List[j].Scores[5] < List[j + 1].Scores[5]) {
					Student temp = List[j];
					List[j] = List[j + 1];
					List[j + 1] = temp;
				}
			}
		}
	}
	void List_Sort_sum() {
		for (int i = 0; i < Size - 1; i++) {
			for (int j = 0; j < Size - i - 1; j++) {
				if (List[j].Scores[6] < List[j + 1].Scores[6]) {
					Student temp = List[j];
					List[j] = List[j + 1];
					List[j + 1] = temp;
				}
			}
		}
	}
	void List_Print() {
		cout << "total:" << Size << endl;
		cout << "Number\tChinese\tMaths\tEnglish\tScience\tSociety\tAverage\tSum\n";
		for (int i = 0; i < Size; i++) {
			cout << List[i].Number << "\t";
			for (int j = 0; j < 7; j++) {
				cout << List[i].Scores[j] << "\t";
			}
			cout << endl;
		}
	}
};
