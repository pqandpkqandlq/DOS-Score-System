#pragma once
//list
#define LIST_MAX 1001
//start
#define VERSION "DOS Score System 1.0 by Nahida,MonkeyKing "
#define WELCOME "Welcome to DOS Score System 1.0"
#define FIRST_USE "If you have some questions please input:help"
//commands
#define ADD "add"
#define DEL "del"
#define CLEAN "clean"
#define SORT "sort"//is not a complete command
#define SORT_CH "sortch"
#define SORT_MATH "sortmath"
#define SORT_ENG "sorteng"
#define SORT_SCI "sortsci"
#define SORT_SOC "sortsoc"
#define SORT_AVER "sortaver"
#define SORT_SUM "sortsum"
#define PRINT "print"
#define HOWMANY "howmany"
#define SAVE "save"
#define LOAD "load"
#define SHUTDOWN "shutdown"
#define HELP "help"
//commands running
#define COMMAND_FAILED "Error:This is not true command"
#define COMMAND_PROMPT ":>"
#define COMMAND_SUCCESS "Done!"