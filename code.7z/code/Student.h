#pragma once
#include<string>
#include"Settings.h"
using namespace std;
class Student {
public:
	double Scores[7];
	string Number;
	Student(string number="00000000", double ch=-1, double math=-1, double eng=-1, double sci=-1, double soc=-1) {
		Number = number;
		Scores[0] = ch;
		Scores[1] = math;
		Scores[2] = eng;
		Scores[3] = sci;
		Scores[4] = soc;
		Scores[6] = ch + math + eng + sci + soc;
		Scores[5] = Scores[6]/5;
		
	}
};